# Tree_Detection > 2025-05-25 4:21pm
https://universe.roboflow.com/syawal/tree_detection-flaws

Provided by a Roboflow user
License: CC BY 4.0

